#include <graphics.h>
#include <mmsystem.h>
#include <iostream>
#include <conio.h>
#include <windows.h>
void selector (int, int, int);
void function_execution (int choice);
void singleplayer ();
void multiplayer ();
void restart_game ();

// Loading
void loading_game (void)
{
    readimagefile ("image/1.jpg", 0, 0, 700, 600);
    settextstyle (TRIPLEX_FONT, HORIZ_DIR, 1);
    outtextxy (213, 480, "Loading, please wait...");
    rectangle (310, 530, 390, 540);
    setcolor (YELLOW);
    for (int i = 0 ; i <= 76 ; i ++)
    {
        rectangle (310 + i, 532, 310 + i, 538);
        delay (1);
    }
    cleardevice ();
}

// Game menu animation
void menu (void)
{
    setbkcolor (BLACK);
    cleardevice ();
    setcolor (3);
    //settextstyle (3, HORIZ_DIR, 1);
    // outtextxy (10, 575, "ROTNO CHANDRA DAS");
    //settextstyle (EUROPEAN_FONT, HORIZ_DIR, 6);
    readimagefile ("image/92.jpg", 30, 30, 660, 150);
    settextstyle (EUROPEAN_FONT, HORIZ_DIR, 5);
    setcolor (12);
    //outtextxy (205, 180, "Main Menu");
    readimagefile ("image/95.jpg", 280, 180, 410, 230);
    readimagefile ("image/65.jpg", 285, 255, 410, 470);
    setcolor (3);
    settextstyle (3, HORIZ_DIR, 4);
    //outtextxy (260, 250, "1");
    //outtextxy (265, 300, "2");
    //outtextxy (275, 350, "3");
    //outtextxy (285, 395, "4");
    //outtextxy (295, 450, "5");
    selector (250, 1, 1);
}

// Menu Selector
void selector (int h, int key, int choice) // Key  = color selection, choice = keyboard numberpad, h = coordinate
{
    if (key == 0)
    {
        setcolor (BLACK);
    }
    else
    {
        setcolor (YELLOW);
    }
    int d = 0;
    int g = 0;
    if (choice == 1)
    {
        d = 20;
        g = 40;
    }
    if (choice == 2)
    {
        d = 20;
        g = 50;
    }
    if (choice == 3)
    {
        d = 30;
        g  = 60;
    }
    if (choice == 4)
    {
        d = 40;
        g = 70;
    }
    if (choice == 5)
    {
        d = 50;
        g = 80;
    }
    if (choice == 6)
    {
        d = 200;
        g = -66;
    }
    if (choice == 7)
    {
        d = -100;
        g = 230;
    }
    char str1 [] = "<";
    char str2 [] = ">";
    settextstyle (0, HORIZ_DIR, 5);
    outtextxy (200 + d, h, str1);
    outtextxy (460 - g, h, str2);
}
void selection (void)
{
    int choice = 1;
    while (1)
    {
        if (GetAsyncKeyState (VK_NUMPAD1))
        {
            selector (250, 1, 1);
            selector (300, 0, 2);
            selector (350, 0, 3);
            selector (400, 0, 4);
            selector (450, 0, 5);
            //PlaySound (TEXT("sounds/select.wav"), NULL, SND_FILENAME);
            choice = 1;
        }
        if (GetAsyncKeyState (VK_NUMPAD2))
        {
            selector (240, 0, 1);
            selector (300, 1, 2);
            selector (350, 0, 3);
            selector (400, 0, 4);
            selector (480, 0, 5);
            //PlaySound (TEXT("sounds/select.wav"), NULL, SND_FILENAME);
            choice = 2;
        }
        if (GetAsyncKeyState (VK_NUMPAD3))
        {
            selector (240, 0, 1);
            selector (300, 0, 2);
            selector (350, 1, 3);
            selector (400, 0, 4);
            selector (450, 0, 5);
            //PlaySound (TEXT("sounds/select.wav"), NULL, SND_FILENAME);
            choice = 3;
        }
        if (GetAsyncKeyState (VK_NUMPAD4))
        {
            selector (240, 0, 1);
            selector (300, 0, 2);
            selector (350, 0, 3);
            selector (390, 1, 4);
            selector (450, 0, 5);
            //PlaySound (TEXT("image/select.wav"), NULL, SND_FILENAME);
            choice = 4;
        }
        if (GetAsyncKeyState (VK_NUMPAD5))
        {
            selector (240, 0, 1);
            selector (300, 0, 2);
            selector (350, 0, 3);
            selector (400, 0, 4);
            selector (450, 1, 5);
            //PlaySound (TEXT("sounds/select.wav"), NULL, SND_FILENAME);
            choice = 5;
        }
        if (GetAsyncKeyState (VK_RETURN)) // Return = enter
        {
            function_execution (choice);
        }
        delay (1);
    }
}

// Escape
void esc_theme (int option)
{
    while (1)
    {
        if (GetAsyncKeyState (VK_ESCAPE))
        {
            cleardevice ();
            menu ();
            //PlaySound (TEXT ("sounds/esc.wav"), NULL, SND_FILENAME);
            selection ();
            function_execution (option);
        }
    }
}

// Quit
void quit ()
{
    while (1)
    {
        if (GetAsyncKeyState (VK_NUMPAD1))
        {
            selector (330, 1, 7);
            selector (330, 0, 6);
            //PlaySound (TEXT ("sounds/menu.wav"), NULL, SND_FILENAME);
            if (GetAsyncKeyState (VK_RETURN))
            {
                //PlaySound (TEXT ("sounds/enter.wav"), NULL, SND_FILENAME);
                closegraph ();
            }
        }
        if (GetAsyncKeyState (VK_NUMPAD2))
        {
            selector (330, 0, 7);
            selector (330, 1, 6);
            //PlaySound (TEXT ("sounds/menu.wav"), NULL, SND_FILENAME);
            if (GetAsyncKeyState (VK_RETURN))
            {
                //PlaySound (TEXT ("sounds/enter.wav"), NULL, SND_FILENAME);
                menu ();
                selection ();
            }
        }
        if (GetAsyncKeyState (VK_ESCAPE))
        {
            menu ();
            //PlaySound (TEXT ("sounds/esc.wav"), NULL, SND_FILENAME);
            selection ();
        }
    }
}

// Game interface
void game_interface ()
{
    int board_color, box_color;
    board_color = 14;
    box_color = 15;
    setcolor (board_color);
    for (int i = 0 ; i < 5 ; i ++)
    {
        // Vertical
        line (148 + i, 75, 148 + i, 525);
        line (298 + i, 75, 298 + i, 525);
        // Horizontal
        line (25, 223 + i, 425, 223 + i);
        line (25, 373 + i, 425, 373 + i);
    }
    setcolor (box_color);
    for (int i = 0 ; i < 5 ; i ++)
    {
        rectangle (450 + i, 25 + i, 675 - i, 575 - i);
    }
    setcolor (8);
    settextstyle (5, HORIZ_DIR, 9);
    outtextxy (50, 85, "1");
    outtextxy (200, 85, "2");
    outtextxy (350, 85, "3");
    outtextxy (50, 235, "4");
    outtextxy (200, 235, "5");
    outtextxy (350, 235, "6");
    outtextxy (50, 385, "7");
    outtextxy (200, 385, "8");
    outtextxy (350, 385, "9");
    readimagefile ("image/83.jpg", 470, 50, 650, 100);
    readimagefile ("image/89.jpg", 490, 120, 640, 160);
    readimagefile ("image/85.jpg", 448, 168, 676, 181);
    //readimagefile ("image/-.jpg", 120, 0, 1000, 700);
    //setcolor (WHITE);
    //settextstyle (3, HORIZ_DIR, 1);
    //outtextxy (463, 550, "Press R to restart the game");
}

// Position of x_a
int p1 = 1, p2 = 1, p3 = 1, p4 = 1, p5 = 1, p6 = 1, p7 = 1, p8 = 1, p9 = 1;
int n = 0;
int a[9] = {-1, -1, -1, -1, -1, -1, -1, -1, -1};
int flag = 0;
int j = 1;
int k = 1;
int x = 0;
void check_multi_winner (int);

// x
void x_o (int place)
{
    int l, t, r, b;
    char ch;
    if  (a[place - 1] == -1)
    {
        if (n % 2 == 0)
        {
            readimagefile ("image/88.jpg", 490, 120, 640, 160);
        }
        else
        {
            readimagefile ("image/89.jpg", 490, 120, 640, 160);
        }
    }
    if (place == 1 && p1 == 1)
    {
        l = 15;
        t = 85;
        r = 145;
        b = 215;
        p1 ++;
        n ++;
    }
    else if (place == 2 && p2 == 1)
    {
        l = 160;
        t = 85;
        r = 290;
        b = 215;
        p2 ++;
        n ++;
    }
    else if (place == 3 && p3 == 1)
    {
        l = 305;
        t = 85;
        r = 435;
        b = 215;
        p3 ++;
        n ++;
    }
    else if (place == 4 && p4 == 1)
    {
        l = 15;
        t = 235;
        r = 145;
        b = 365;
        p4 ++;
        n ++;
    }
    else if (place == 5 && p5 == 1)
    {
        l = 160;
        t = 235;
        r = 290;
        b = 365;
        p5 ++;
        n ++;
    }
    else if (place == 6 && p6 == 1)
    {
        l = 305;
        t = 235;
        r = 435;
        b = 365;
        p6 ++;
        n ++;
    }
    else if (place == 7 && p7 == 1)
    {
        l = 15;
        t = 385;
        r = 145;
        b = 515;
        p7 ++;
        n ++;
    }
    else if (place == 8 && p8 == 1)
    {
        l = 160;
        t = 385;
        r = 290;
        b = 515;
        p8 ++;
        n ++;
    }
    else if (place == 9 && p9 == 1)
    {
        l = 305;
        t = 385;
        r = 435;
        b = 515;
        p9 ++;
        n ++;
    }
    if (a[place - 1] == -1)
    {
        if (n % 2 == 0)
        {
            ch ='O';
            j ++;
        }
        else
        {
            ch = 'X';
            k ++;
        }
    }
    if (ch == 'O')
    {
        readimagefile ("image/09.jpg", l, t, r, b);
        //PlaySound (TEXT ("sounds/oblue.wav"), NULL, SND_FILENAME);
    }
    else if (ch == 'X')
    {
        readimagefile ("image/08.jpg", l, t, r, b);
        //PlaySound (TEXT ("sounds/xred.wav"), NULL, SND_FILENAME);
    }
    if (ch == 'O')
    {
        a[place - 1] = 0;
        check_multi_winner (0);
    }
    if (ch == 'X')
    {
        a[place - 1] = 1;
        check_multi_winner (1);
    }
    if (j >= 5 && k >= 6)
    {
        j = 1;
        k = 1;
        check_multi_winner (2);
    }
}

// Check winning
void check_multi_winner (int no)
{
    if (a[0] == no && a[1] == no && a[2] == no)
    {
        flag ++;
    }
    if (a[3] == no && a[4] == no && a[5] == no)
    {
        flag ++;
    }
    if (a[6] == no && a[7] == no && a[8] == no)
    {
        flag++;
    }
    if (a[0] == no && a[3] == no && a[6] == no)
    {
        flag++;
    }
    if (a[1] == no && a[4] == no && a[7] == no)
    {
        flag++;
    }
    if (a[2] == no && a[5] == no && a[8] == no)
    {
        flag++;
    }
    if (a[2] == no && a[4] == no && a[6] == no)
    {
        flag++;
    }
    if (a[0] == no && a[4] == no && a[8] == no)
    {
        flag++;
    }
    if (flag == 1)
    {
        if (no == 0)
        {
            readimagefile("image/80.jpg", 448, 325, 680, 390);
            //PlaySound(TEXT("sounds/winner.wav"), NULL, SND_FILENAME);
        }
        if (no == 1)
        {
            readimagefile("image/81.jpg", 448, 325, 680, 390);
            //PlaySound(TEXT("sounds/winner.wav"), NULL, SND_FILENAME);
        }
    }
    else if (flag == 0 && no == 2)
    {
        readimagefile("image/82.jpg", 465, 320, 660, 380);
        //PlaySound(TEXT("sounds/noone.wav"), NULL, SND_FILENAME);
        x = 2;
    }
    restart_game();
}

// Restart Game
void restart_game()
{
    if (flag == 1 || (flag == 0 && x == 2))
    {
        setcolor(RED);
        settextstyle(3, HORIZ_DIR, 2);
        //outtextxy(490, 430, "Wait 5 Second To");
        //outtextxy(500, 450, "Restart Game!");
        delay(5000);
        p1 = 1, p2 = 1, p3 = 1, p4 = 1, p5 = 1, p6 = 1, p7 = 1, p8 = 1, p9 = 1;
        n = 0;
        flag = 0;
        j = 1;
        k = 1;
        x = 0;
        for (int i = 0; i < 9; i++)
        {
            a[i] = -1;
        }
        //function_execution(2);
        //esc_theme(2);
    }
}

// Single Player Logic
void singleplayer()
{
    int place = 0;
    while(1)
    {
        if(n%2==0)
        {
            place=1+(rand()%9);
            x_o(place);
        }
        else
        {
            if(GetAsyncKeyState(VK_NUMPAD1))
            {
                place=1;
                x_o(place);
            }
            if(GetAsyncKeyState(VK_NUMPAD2))
            {
                place=2;
                x_o(place);
            }
            if(GetAsyncKeyState(VK_NUMPAD3))
            {
                place=3;
                x_o(place);
            }
            if(GetAsyncKeyState(VK_NUMPAD4))
            {
                place=4;
                x_o(place);
            }
            if(GetAsyncKeyState(VK_NUMPAD5))
            {
                place=5;
                x_o(place);
            }
            if(GetAsyncKeyState(VK_NUMPAD6))
            {
                place=6;
                x_o(place);
            }
            if(GetAsyncKeyState(VK_NUMPAD7))
            {
                place=7;
                x_o(place);
            }
            if(GetAsyncKeyState(VK_NUMPAD8))
            {
                place=8;
                x_o(place);
            }
            if(GetAsyncKeyState(VK_NUMPAD9))
            {
                place=9;
                x_o(place);
            }
            if(GetAsyncKeyState(VK_ESCAPE))
            {
                p1=1,p2=1,p3=1,p4=1,p5=1,p6=1,p7=1,p8=1,p9=1;
                n=0;
                flag=0;
                for(int i=0; i<9; i++)
                {
                    a[i]=-1;
                }
                menu ();
                break;
            }
            if (GetAsyncKeyState(VK_NUMPAD0))
            {
                p1 = 1, p2 = 1, p3 = 1, p4 = 1, p5 = 1, p6 = 1, p7 = 1, p8 = 1, p9 = 1;
                n = 0;
                flag = 0;
                j = 1;
                k = 1;
                x = 0;
                for (int i = 0; i < 9; i++)
                {
                    a[i] = -1;
                }
                cleardevice();
                game_interface();
                // PlaySound(TEXT("sounds/restart.wav"), NULL, SND_FILENAME);
            }
        }
    }
}

// Multiplayer Logic
void multiplayer()
{
    readimagefile("image/83.jpg", 470, 50, 650, 100);
    readimagefile("image/89.jpg", 490, 120, 640, 160);
    //readimagefile("image/winner1.jpg", 480, 160, 640, 200);
    //readimagefile("images/-.gif", 120, 0, 1000, 700);
    int place = 0;
    while (1)
    {
        if (GetAsyncKeyState(VK_NUMPAD1))
        {
            place = 1;
            x_o(place);
        }
        if (GetAsyncKeyState(VK_NUMPAD2))
        {
            place = 2;
            x_o(place);
        }
        if (GetAsyncKeyState(VK_NUMPAD3))
        {
            place = 3;
            x_o(place);
        }
        if (GetAsyncKeyState(VK_NUMPAD4))
        {
            place = 4;
            x_o(place);
        }
        if (GetAsyncKeyState(VK_NUMPAD5))
        {
            place = 5;
            x_o(place);
        }
        if (GetAsyncKeyState(VK_NUMPAD6))
        {
            place = 6;
            x_o(place);
        }
        if (GetAsyncKeyState(VK_NUMPAD7))
        {
            place = 7;
            x_o(place);
        }
        if (GetAsyncKeyState(VK_NUMPAD8))
        {
            place = 8;
            x_o(place);
        }
        if (GetAsyncKeyState(VK_NUMPAD8))
        {
            place = 8;
            x_o(place);
        }
        if (GetAsyncKeyState(VK_NUMPAD9))
        {
            place = 9;
            x_o(place);
        }
        if (GetAsyncKeyState(VK_ESCAPE))
        {
            p1 = 1, p2 = 1, p3 = 1, p4 = 1, p5 = 1, p6 = 1, p7 = 1, p8 = 1, p9 = 1;
            n = 0;
            flag = 0;
            j = 1;
            k = 1;
            x = 0;
            for (int i = 0; i < 9; i++)
            {
                a[i] = -1;
            }
            menu();
            //PlaySound(TEXT("sounds/esc.wav"), NULL, SND_FILENAME);
            break;
        }
        if (GetAsyncKeyState(VK_NUMPAD0))
        {
            p1 = 1, p2 = 1, p3 = 1, p4 = 1, p5 = 1, p6 = 1, p7 = 1, p8 = 1, p9 = 1;
            n = 0;
            flag = 0;
            j = 1;
            k = 1;
            x = 0;
            for (int i = 0; i < 9; i++)
            {
                a[i] = -1;
            }
            cleardevice();
            game_interface();
            // PlaySound(TEXT("sounds/restart.wav"), NULL, SND_FILENAME);
        }
    }
}

// Function execution
void function_execution (int choice)
{
    if (choice == 1)
    {
        cleardevice ();
        game_interface ();
        /*setcolor (14);
        settextstyle (5, HORIZ_DIR, 6);
        outtextxy (150, 250, "Not Updated Yet...");  // Single player logic
        //PlaySound (TEXT ("sounds/enter.wav"), NULL, SND_FILENAME);*/
        singleplayer ();
        esc_theme (1);
    }
    if (choice == 2)
    {
        cleardevice ();
        game_interface ();
        //PlaySound (TEXT ("sounds/enter.wav"), NULL, SND_FILENAME);
        multiplayer (); // Multi player Logic
    }
    if (choice == 3)
    {
        cleardevice ();
        readimagefile ("image/78.jpg", 50, 70, 650, 540);
        //PlaySound (TEXT ("sounds/enter.wav"), NULL, SND_FILENAME);
        esc_theme (3);
    }
    if (choice == 4)
    {
        int page = 0;
        // PlaySound (TEXT ("sounds/enter.wav"), NULL, SND_FILENAME);
        cleardevice ();
        for (int i = 200 ; i <= 1300 ; i ++)
        {
            setfillstyle (SOLID_FILL, BLACK);
            readimagefile ("image/75.jpg", 0, 800 - i, 700, 1300 - i);
            bar (50, 1320 - i, 650, 2000 - i);
            if (GetAsyncKeyState (VK_ESCAPE))
            {
                break;
            }
            page = 1 - page;
            delay (1);
        }
        menu ();
        //PlaySound (TEXT ("sounds/esc.wav"), NULL, SND_FILENAME);
        selection ();
    }
    if (choice == 5)
    {
        cleardevice ();
        setcolor (13);
        settextstyle (3, HORIZ_DIR, 4);
        outtextxy (140, 330, "1");
        outtextxy (440, 330, "2");
        readimagefile ("image/50.jpg", 50, 220, 650, 150);
        readimagefile ("image/51.jpg", 160, 325, 272, 365);
        readimagefile ("image/52.jpg", 470, 325, 580, 368);
        //PlaySound (TEXT ("sokunds/enter.wav"), NULL, SND_FILENAME);
        quit ();
    }
}

// Driver
int main ()
{
    initwindow (700, 600, "Tic Tac Toe", 150, 150);
    loading_game ();
    menu ();
    //PlaySound (TEXT ("sounds/select.wav"), NULL, SND_SYNC);
    selection ();
    getch ();
    closegraph ();
}
